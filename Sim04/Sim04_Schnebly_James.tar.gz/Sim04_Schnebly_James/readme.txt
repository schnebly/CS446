James Schnebly
CS446
Proj.4 readme.txt
11/4/2017

************Memory and resources are reset upon load of each new process************

Sim04.cpp
---------
Line 42: PCB Stuct
Line 60: error check for conf argument
Line 70: error check for correct extension
Line 88: Parse + load config
Line 100: Parse + load meta-data
Line 182: runFIFO()
Line 639: loadOneMetaData()
Line 676: setupCursor()
Line 686: printMetaData()
Line 696: printToLog()
Line 716: myWait()
Line 725: runner()
Line 732: sjfSetup()
Line 873: getTotalProcesses()
Line 890: psSetup()


meta_class.cpp
--------------

Line 16 - 67: Constructor + destructor and Getter + Setter Functions
Line 69: printNode()


config_class.cpp
----------------
Line 15-37: Constructor + destructor functions
Line 42: loadConfig(...)
Line 202: printConfig()
Line 224+: Getter + setter functions

MemoryFunction.c
-----------------
Line 21: allocateMemory

