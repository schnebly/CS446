******	Project 3 CS446 Readme	*******

  Author: James Schnebly
  Title: Sim03.cpp
  Class: CS446/646
  Date: 10/26/2017

******
Siming told us in class that printer and hard drive are the only resources for this project that can have qunatity higher than 1 therefore they are the only ones specified on the config as a given quantity. 
******

Sim03.cpp
---------
Line 39: PCB Stuct
Line 56: error check for conf argument
Line 66: error check for correct extension
Line 84: Parse + load config
Line 96: Parse + load meta-data
Line 125: Run function(main function)
Line 568: loadOneMetaData(...)
Line 605: setupCursor(...)
Line 615: printMetaData(...)
Line 625: printToLog(...)
Line 645: myWait()
Line 654: runner()

meta_class.cpp
--------------

Line 16 - 67: Constructor + destructor and Getter + Setter Functions
Line 69: printNode()


config_class.cpp
----------------
Line 15-37: Constructor + destructor functions
Line 42: loadConfig(...)
Line 202: printConfig()
Line 224+: Getter + setter functions

MemoryFunction.c
-----------------
Line 21: allocateMemory

