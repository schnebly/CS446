James Schnebly CS446 Proj.1

Sim01.cpp
---------

Line 27: error check for conf argument
Line 37: error check for correct extension
Line 54: Parse + load config
Line 66: Parse + load meta-data
Line 84: Display to Monitor/File
Line 144: loadOneMetaData(...)
Line 182: setupCursor(...)
Line 192: printMetaData(...)
Line 202: printToLog(...)
Line 223: processMetaDataNode(...)

meta_class.cpp
--------------

Line 16 - 67: Constructor + destructor and Getter + Setter Functions
Line 69: printNode()


config_class.cpp
----------------
Line 15-37: Constructor + destructor functions
Line 40: loadConfig(...)
Line 134: printConfig()
Line 152+: Getter + setter functions
