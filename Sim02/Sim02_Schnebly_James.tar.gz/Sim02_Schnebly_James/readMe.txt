James Schnebly CS446 Proj.2

Sim02.cpp
---------

Line 27: error check for conf argument
Line 37: error check for correct extension
Line 54: Parse + load config
Line 66: Parse + load meta-data
Line 123: Run function(main function)
Line 554: loadOneMetaData(...)
Line 591: setupCursor(...)
Line 601: printMetaData(...)
Line 611: printToLog(...)
Line 631: myWait()
Line 640: runner()

meta_class.cpp
--------------

Line 16 - 67: Constructor + destructor and Getter + Setter Functions
Line 69: printNode()


config_class.cpp
----------------
Line 15-37: Constructor + destructor functions
Line 40: loadConfig(...)
Line 134: printConfig()
Line 152+: Getter + setter functions
